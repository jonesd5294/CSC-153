﻿/**
 * 3/15/2023
 * CSC 153
 * David Jones
 * This program will call a method from class library and calculate the distance an object fell.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using FallingLibrary;


namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Call user variable and declare double 
             double time = double.Parse(timeTextBox.Text);

            //Call class Library and create and instance
             Library library = new Library();                                  

            //Call methodDisplay the distance traveled
            MessageBox.Show("The object traveled: " + library.FallingDistance(time).ToString() + " meters.");
               
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
