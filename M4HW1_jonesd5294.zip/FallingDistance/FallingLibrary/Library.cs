﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace FallingLibrary
{
    public class Library
    {
        public double FallingDistance(double time)
        {
            //Declare constant GRAVITY
            const double GRAVITY = 9.8;
            //Calculate for distance
            double distance = (0.5) * (GRAVITY) * (Math.Pow(time, 2));
            //Return distance
            return distance;
        }
    }
}
