﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms
{
    class Car
    {
        //Create field for make and year
        private string _year;
        private string _make;
        private int _speed = 0;

        //Constructor for year and make
        public Car()
        {
            _year = "";
            _make = "";           
        }

        //Year property
        public string Year
        {
            get { return _year; }
            set { _year = value; }
            
        }

        //Make property
        public string Make
        {
            get { return _make; }
            set { _make = value; }

        }

        //Speed proptery
        public int Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }
        
        public void Break()
        {
            if (Speed != 0)
            {
                Speed -= 5;
            }

        }

        //Accelerate method
        public void Accelerate()
        {
            Speed += 5;
        }
        

        
    }
}
