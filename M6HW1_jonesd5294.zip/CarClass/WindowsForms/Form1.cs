﻿/**
 * 4/26/2023
 * CSC 153
 * David Jones
 * This program will display the users make and year of the input vehicle's speed.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Create car object
        Car thisCar = new Car();

        private void accelButton_Click(object sender, EventArgs e)
        {
            //Get user make
            thisCar.Make = makeTextBox.Text;
            //get user year
            thisCar.Year = yearTextBox.Text;
            //Call Accelerate Method from Car class
            thisCar.Accelerate();
            //Display the year, make and speed
            MessageBox.Show($"Your {thisCar.Year} {thisCar.Make} is going {thisCar.Speed}mph.");

        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            //Call break method from car class
            thisCar.Break();
            //Dispaly the year, make and speed
            MessageBox.Show($"Your {thisCar.Year} {thisCar.Make} is going {thisCar.Speed}mph.");

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close program
            this.Close();
        }
    }
}
