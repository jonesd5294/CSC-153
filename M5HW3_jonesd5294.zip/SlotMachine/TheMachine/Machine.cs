﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace TheMachine
{
    public static class Machine
    {
        //public static void ClearAll()
        //{
        //    pictureBox1.Image = null;
        //    pictureBox2.Image = null;
        //    pictureBox3.Image = null;

        //}

        //Validate input bool
        //private static bool Validate(double usrInsert)
        //{
        //    bool valid = false;

        //    try
        //    {
        //        usrInsert = double.Parse(str);

        //        if (usrInsert > 0.00)
        //            valid = true;
        //        totalInsert = totalInsert + usrInsert;
        //    }
        //    catch
        //    {
        //        MessageBox.Show("Please enter a valid amount.");
        //    }

        //    return valid;
        //}

        //public static void GambleSpin(int num1, int num2, int num3)
        //{
        //    amountWon = 0;

        //    if (num1 != num2 && num1 != num3 && num2 != num3)
        //    {
        //        MessageBox.Show("You have won $0.00");
        //    }
        //    else if (num1 == num2 && num1 != num3)
        //    {
        //        amountWon = usrInsert * 2;
        //        totalWon = totalWon + amountWon;
        //        MessageBox.Show("You won $" + amountWon.ToString("n2"));
        //    }
        //    else if (num1 != num2 && num1 == num3)
        //    {
        //        amountWon = usrInsert * 2;
        //        totalWon = totalWon + amountWon;
        //        MessageBox.Show("You won $" + amountWon.ToString("n2"));
        //    }
        //    else if (num1 != num2 && num2 == num3)
        //    {
        //        amountWon = usrInsert * 2;
        //        totalWon = totalWon + amountWon;
        //        MessageBox.Show("You won $" + amountWon.ToString("n2"));
        //    }
        //    else if (num1 == num2 && num1 == num3)
        //    {
        //        amountWon = usrInsert * 3;
        //        totalWon = totalWon + amountWon;
        //        MessageBox.Show("You won $" + amountWon.ToString("n2"));
        //    }
        //}

    }
}
