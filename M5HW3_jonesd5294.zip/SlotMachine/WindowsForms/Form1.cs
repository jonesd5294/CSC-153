﻿/**
 * 4/23/2023
 * CSC 153
 * David Jones
 * This program will simulate a slot machine
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using TheMachine;


namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Declare random number variables
        Random rand = new Random();

        //Declare integer variables
        int ranNum1, ranNum2, ranNum3;

        //Declare double variables
        double usrInsert, amountWon;
        double totalInsert = 0.00;
        double totalWon = 0.00;

        //Calculations and if else statements for Gambling Method
        private void Gamble(int num1, int num2, int num3)
        {
            amountWon = 0;

            if (num1 != num2 && num1 != num3 && num2 != num3)
            {
                MessageBox.Show("You have won $0.00");
            }
            else if (num1 == num2 && num1 != num3)
            {
                amountWon = usrInsert * 2;
                totalWon = totalWon + amountWon;
                MessageBox.Show("You won $" + amountWon.ToString("n2"));
            }
            else if (num1 != num2 && num1 == num3)
            {
                amountWon = usrInsert * 2;
                totalWon = totalWon + amountWon;
                MessageBox.Show("You won $" + amountWon.ToString("n2"));
            }
            else if (num1 != num2 && num2 == num3)
            {
                amountWon = usrInsert * 2;
                totalWon = totalWon + amountWon;
                MessageBox.Show("You won $" + amountWon.ToString("n2"));
            }
            else if (num1 == num2 && num1 == num3)
            {
                amountWon = usrInsert * 3;
                totalWon = totalWon + amountWon;
                MessageBox.Show("You won $" + amountWon.ToString("n2"));
            }
        }

        //Validate input bool
        private bool ValidInput(string str)
        {
            bool valid = false;

            try
            {
                usrInsert = double.Parse(str);

                if (usrInsert > 0.00)
                    valid = true;
                totalInsert = totalInsert + usrInsert;
            }
            catch
            {
                MessageBox.Show("Please enter a valid amount.");
            }

            return valid;
        }

        //Clear the images
        private void ClearPics()
        {
            pictureBox1.Image = null;
            pictureBox2.Image = null;
            pictureBox3.Image = null;
        }     
                

        private void spinButton_Click(object sender, EventArgs e)
        {
            //Get user variable
            string input = amountTextBox.Text; 
            //Call Validate input Method
            if (ValidInput(input))
            {
                //Declare random numbers to variables
                ranNum1 = rand.Next(10);
                ranNum2 = rand.Next(10);
                ranNum3 = rand.Next(10);

                //Assing random image to picture box 
                pictureBox1.Image = imageList1.Images[ranNum1];
                pictureBox2.Image = imageList2.Images[ranNum2];
                pictureBox3.Image = imageList3.Images[ranNum3];

                //Call Gambling Method
                Gamble(ranNum1, ranNum2, ranNum3);

                //Call clear images method                
                ClearPics();

                //Clear the text box
                amountTextBox.Text = "";
                amountTextBox.Focus();

            }           
            

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Display Exit message with total won and spent
            MessageBox.Show("Your amount spent $" + totalInsert.ToString("n2") + "\n\n" + "You won $" + totalWon.ToString("n2"));
            this.Close();
        }
    }
}
