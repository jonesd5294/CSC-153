﻿/**
 * 3/12/2023
 * CSC 153
 * David Jones
 * This program will display text files in a listbox
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
               
        private void readButton_Click(object sender, EventArgs e)
        {
            //Try catch method
            try
            {
                //Initialize StreamReader
                StreamReader inputFile;
                //Declare variables
                int counter = 0;
                int total = 0;
                int number;             
                
                //If Else statement
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    //Open the file and get Stream Reader object
                    inputFile = File.OpenText(openFileDialog1.FileName);

                    //While statement for end of file and processessing
                    while (!inputFile.EndOfStream)
                    {
                        //Read the number add to list box
                        number = int.Parse(inputFile.ReadLine());
                        textlistBox.Items.Add(number);
                        //Counter and total calculations
                        total += number;
                        counter++;
                        
                    }
                    //Display total and numbers to list box
                    textlistBox.Items.Add("The total of the numbers are: " + total);
                    textlistBox.Items.Add("The number of random numbers are: " + counter);
                }
                //Else statement
                else
                {
                    //You clicked cancel message
                    MessageBox.Show("You clicked cancel.");
                }
                

            }
            catch
            {
                //Try again message
                MessageBox.Show("Please try again.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Exit program
            this.Close();
        }
    }
}
