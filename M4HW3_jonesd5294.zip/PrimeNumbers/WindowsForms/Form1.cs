﻿/**
 * 3/29/2023
 * CSC 153
 *David Jones
 *This program will calculate a usern number and display if it's a prime number
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            //Try statement
            try
            {
                //Call user variable and declare int
                int number = int.Parse(numberTextBox.Text);

                //Call IsPrime method and dispaly results
                MessageBox.Show("Is " + number + " a prime number? " + Library.IsPrime(number).ToString());

            }
            //Catch statement
            catch(Exception ex)
            {
                MessageBox.Show("Please enter a number.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close program
            this.Close();
        }
    }
}
