﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class Library
    {
        //Prime number  boolean Method
        public static bool IsPrime(int number)
        {
            //Declare boolean variables
            bool numberIsPrime;
            //If else statement and calculate even or prime number
            if (number % 2 == 0)
            {
                numberIsPrime = false;
            }
            else
            {
                numberIsPrime = true;
            }
            return numberIsPrime;
        }
    }
}
