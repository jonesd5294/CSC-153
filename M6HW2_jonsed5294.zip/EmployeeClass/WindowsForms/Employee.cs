﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms
{
    class Employee
    {
        //Create fields for name, idnumber, department, position
        private string _name;
        private int _idNum;
        private string _deparment;
        private string _position;

        //Constructor for all fields
        public Employee()
        {
            _name = "";
            _idNum = 0;
            _deparment = "";
            _position = "";
        }
       
        //Name property
        public string Name
        {
            get { return _name;  }
            set { _name = value; }
        }

        //ID Number property
        public int Id
        {
            get { return _idNum; }
            set { _idNum = value; }
        }

        //Department property
        public string Department
        {
            get { return _deparment; }
            set { _deparment = value; }
        }

        //Position property
        public string Position
        {
            get { return _position; }
            set { _position = value; }
        }

        //Overloaded Dep/Position "" Constructor
        public Employee(string _department, string _position)
        {
            Department = "";
            Position = "";
        }

        //Parameterless Constructor Clear values
        //public Employee()
        //{
        //    Name = "";
        //    Id = 0;
        //    Department = "";
        //    Position = "";
        //}

    }
}
