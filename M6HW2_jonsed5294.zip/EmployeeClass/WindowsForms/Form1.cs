﻿/**
 * 4/30/2023
 * CSC 153
 * David Jones
 * This program will contain an employee class to store data
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Create Employee object
        Employee thisEmp = new Employee();

        private void enterButton_Click(object sender, EventArgs e)
        {
            //Get user name
            thisEmp.Name = nameTextBox.Text;
            //Get user id number
            thisEmp.Id = int.Parse(idNumTextBox.Text);
            //Get user Department
            thisEmp.Department = depTextBox.Text;
            //Get user Position
            thisEmp.Position = posTextBox.Text;

            //Display Test
            MessageBox.Show($" {thisEmp.Name} {thisEmp.Id} {thisEmp.Department} {thisEmp.Position}");

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close program
            this.Close();
        }
    }
}
