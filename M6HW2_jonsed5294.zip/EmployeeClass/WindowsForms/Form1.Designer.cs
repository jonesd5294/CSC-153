﻿
namespace WindowsForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.idNumLabel = new System.Windows.Forms.Label();
            this.depLabel = new System.Windows.Forms.Label();
            this.posLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.idNumTextBox = new System.Windows.Forms.TextBox();
            this.depTextBox = new System.Windows.Forms.TextBox();
            this.posTextBox = new System.Windows.Forms.TextBox();
            this.enterButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(27, 27);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(38, 13);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name:";
            // 
            // idNumLabel
            // 
            this.idNumLabel.AutoSize = true;
            this.idNumLabel.Location = new System.Drawing.Point(27, 79);
            this.idNumLabel.Name = "idNumLabel";
            this.idNumLabel.Size = new System.Drawing.Size(61, 13);
            this.idNumLabel.TabIndex = 1;
            this.idNumLabel.Text = "ID Number:";
            // 
            // depLabel
            // 
            this.depLabel.AutoSize = true;
            this.depLabel.Location = new System.Drawing.Point(27, 124);
            this.depLabel.Name = "depLabel";
            this.depLabel.Size = new System.Drawing.Size(65, 13);
            this.depLabel.TabIndex = 2;
            this.depLabel.Text = "Department:";
            // 
            // posLabel
            // 
            this.posLabel.AutoSize = true;
            this.posLabel.Location = new System.Drawing.Point(27, 168);
            this.posLabel.Name = "posLabel";
            this.posLabel.Size = new System.Drawing.Size(47, 13);
            this.posLabel.TabIndex = 3;
            this.posLabel.Text = "Position:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(109, 27);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 4;
            // 
            // idNumTextBox
            // 
            this.idNumTextBox.Location = new System.Drawing.Point(109, 72);
            this.idNumTextBox.Name = "idNumTextBox";
            this.idNumTextBox.Size = new System.Drawing.Size(100, 20);
            this.idNumTextBox.TabIndex = 5;
            // 
            // depTextBox
            // 
            this.depTextBox.Location = new System.Drawing.Point(109, 117);
            this.depTextBox.Name = "depTextBox";
            this.depTextBox.Size = new System.Drawing.Size(100, 20);
            this.depTextBox.TabIndex = 6;
            // 
            // posTextBox
            // 
            this.posTextBox.Location = new System.Drawing.Point(109, 161);
            this.posTextBox.Name = "posTextBox";
            this.posTextBox.Size = new System.Drawing.Size(100, 20);
            this.posTextBox.TabIndex = 7;
            // 
            // enterButton
            // 
            this.enterButton.Location = new System.Drawing.Point(251, 389);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(75, 23);
            this.enterButton.TabIndex = 8;
            this.enterButton.Text = "Enter";
            this.enterButton.UseVisualStyleBackColor = true;
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(488, 389);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.enterButton);
            this.Controls.Add(this.posTextBox);
            this.Controls.Add(this.depTextBox);
            this.Controls.Add(this.idNumTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.posLabel);
            this.Controls.Add(this.depLabel);
            this.Controls.Add(this.idNumLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label idNumLabel;
        private System.Windows.Forms.Label depLabel;
        private System.Windows.Forms.Label posLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox idNumTextBox;
        private System.Windows.Forms.TextBox depTextBox;
        private System.Windows.Forms.TextBox posTextBox;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.Button exitButton;
    }
}

