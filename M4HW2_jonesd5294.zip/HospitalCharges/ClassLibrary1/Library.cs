﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public static class Library
    {
        //CalcStayCharges Method
        public static decimal CalcStayCharges(decimal days)
        {
            //Return stay
            return days * 350.0m;
        }

        //CalcMiscCharges Method
        public static decimal CalcMiscCharges(decimal meds, decimal surg, decimal labs, decimal phys)
        {
            //Return misc
            return meds + surg + labs + phys; ;
        }

        //CalcTotalCharges Method
        public static decimal CalcTotalCharges(decimal misc, decimal stay)
        {
            //Return total
            return misc + stay;
        }
    }
}
