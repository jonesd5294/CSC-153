﻿
namespace WindowsForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.daysLabel = new System.Windows.Forms.Label();
            this.daysTextBox = new System.Windows.Forms.TextBox();
            this.medsLabel = new System.Windows.Forms.Label();
            this.medsTextBox = new System.Windows.Forms.TextBox();
            this.surgLabel = new System.Windows.Forms.Label();
            this.surgTextBox = new System.Windows.Forms.TextBox();
            this.labLabel = new System.Windows.Forms.Label();
            this.labTextBox = new System.Windows.Forms.TextBox();
            this.physLabel = new System.Windows.Forms.Label();
            this.physTextBox = new System.Windows.Forms.TextBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // daysLabel
            // 
            this.daysLabel.AutoSize = true;
            this.daysLabel.Location = new System.Drawing.Point(42, 39);
            this.daysLabel.Name = "daysLabel";
            this.daysLabel.Size = new System.Drawing.Size(186, 13);
            this.daysLabel.TabIndex = 0;
            this.daysLabel.Text = "Enter number of days spent in hospital";
            // 
            // daysTextBox
            // 
            this.daysTextBox.Location = new System.Drawing.Point(312, 32);
            this.daysTextBox.Name = "daysTextBox";
            this.daysTextBox.Size = new System.Drawing.Size(100, 20);
            this.daysTextBox.TabIndex = 1;
            // 
            // medsLabel
            // 
            this.medsLabel.AutoSize = true;
            this.medsLabel.Location = new System.Drawing.Point(45, 96);
            this.medsLabel.Name = "medsLabel";
            this.medsLabel.Size = new System.Drawing.Size(133, 13);
            this.medsLabel.TabIndex = 2;
            this.medsLabel.Text = "Enter charges for medicine";
            // 
            // medsTextBox
            // 
            this.medsTextBox.Location = new System.Drawing.Point(312, 88);
            this.medsTextBox.Name = "medsTextBox";
            this.medsTextBox.Size = new System.Drawing.Size(100, 20);
            this.medsTextBox.TabIndex = 3;
            // 
            // surgLabel
            // 
            this.surgLabel.AutoSize = true;
            this.surgLabel.Location = new System.Drawing.Point(45, 156);
            this.surgLabel.Name = "surgLabel";
            this.surgLabel.Size = new System.Drawing.Size(180, 13);
            this.surgLabel.TabIndex = 4;
            this.surgLabel.Text = "Enter amount for surgical procedures";
            // 
            // surgTextBox
            // 
            this.surgTextBox.Location = new System.Drawing.Point(312, 148);
            this.surgTextBox.Name = "surgTextBox";
            this.surgTextBox.Size = new System.Drawing.Size(100, 20);
            this.surgTextBox.TabIndex = 5;
            // 
            // labLabel
            // 
            this.labLabel.AutoSize = true;
            this.labLabel.Location = new System.Drawing.Point(48, 222);
            this.labLabel.Name = "labLabel";
            this.labLabel.Size = new System.Drawing.Size(107, 13);
            this.labLabel.TabIndex = 6;
            this.labLabel.Text = "Enter amount for labs";
            // 
            // labTextBox
            // 
            this.labTextBox.Location = new System.Drawing.Point(312, 214);
            this.labTextBox.Name = "labTextBox";
            this.labTextBox.Size = new System.Drawing.Size(100, 20);
            this.labTextBox.TabIndex = 7;
            // 
            // physLabel
            // 
            this.physLabel.AutoSize = true;
            this.physLabel.Location = new System.Drawing.Point(51, 281);
            this.physLabel.Name = "physLabel";
            this.physLabel.Size = new System.Drawing.Size(188, 13);
            this.physLabel.TabIndex = 8;
            this.physLabel.Text = "Enter amount for physcial rehabilitation";
            // 
            // physTextBox
            // 
            this.physTextBox.Location = new System.Drawing.Point(312, 281);
            this.physTextBox.Name = "physTextBox";
            this.physTextBox.Size = new System.Drawing.Size(100, 20);
            this.physTextBox.TabIndex = 9;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(105, 367);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(75, 23);
            this.calcButton.TabIndex = 10;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(339, 367);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.physTextBox);
            this.Controls.Add(this.physLabel);
            this.Controls.Add(this.labTextBox);
            this.Controls.Add(this.labLabel);
            this.Controls.Add(this.surgTextBox);
            this.Controls.Add(this.surgLabel);
            this.Controls.Add(this.medsTextBox);
            this.Controls.Add(this.medsLabel);
            this.Controls.Add(this.daysTextBox);
            this.Controls.Add(this.daysLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label daysLabel;
        private System.Windows.Forms.TextBox daysTextBox;
        private System.Windows.Forms.Label medsLabel;
        private System.Windows.Forms.TextBox medsTextBox;
        private System.Windows.Forms.Label surgLabel;
        private System.Windows.Forms.TextBox surgTextBox;
        private System.Windows.Forms.Label labLabel;
        private System.Windows.Forms.TextBox labTextBox;
        private System.Windows.Forms.Label physLabel;
        private System.Windows.Forms.TextBox physTextBox;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Button exitButton;
    }
}

