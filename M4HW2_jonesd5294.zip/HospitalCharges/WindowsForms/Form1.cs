﻿/**
 * 3/26/2023
 * CSC 153
 * David Jones
 *This program will calculate the totale hospital charges entered by the user
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary1;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        decimal stay = 0;
        decimal misc = 0;
       
        private void calcButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Call  user variables and declare
                decimal days = decimal.Parse(daysTextBox.Text);
                decimal meds = decimal.Parse(medsTextBox.Text);
                decimal surg = decimal.Parse(surgTextBox.Text);
                decimal labs = decimal.Parse(labTextBox.Text);
                decimal phys = decimal.Parse(physTextBox.Text);


                //Call method to calculate stay charges and return stay
                stay = Library.CalcStayCharges(days);

                //Call method to calculate misc charges and return misc
                misc = Library.CalcMiscCharges(meds, surg, labs, phys);

                //Call method to caclulate total and display total charges
                MessageBox.Show("The total charges: " + Library.CalcTotalCharges(misc, stay).ToString());
            }
            catch(Exception ex)
            {
                //Display error Message 
                MessageBox.Show("Please enter the charges.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
