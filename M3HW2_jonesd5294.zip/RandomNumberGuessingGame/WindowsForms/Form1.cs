﻿/**
 * 3/1/2023
 * CSC 153
 * David Jones
 * This program will ask a user to get a random number
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Declare variables
        int number;
        Random rand = new Random();
        int count = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            number = rand.Next(1, 101);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            //Get user number and declare user variable
            int num = int.Parse(numTextBox.Text);
            //Begin counter
            count++;
                        
            //if else if else statement
            if (num == number)
            {
                MessageBox.Show("You guessed right!");
                number = rand.Next(1, 101);
                count = 0;
            }
            else if (num > number)
            {
                MessageBox.Show("Too high, tray again.");
            }
            else
            {
                MessageBox.Show("Too low, try again.");
            }
            //Clear input
            numTextBox.Clear();
            counterLabel.Text = count.ToString();
        }

        //Close Program
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
