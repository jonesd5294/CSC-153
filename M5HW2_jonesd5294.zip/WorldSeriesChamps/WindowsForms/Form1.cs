﻿/**
 * 4/16/2023
 * CSC 153
 * David Jones
 * This program will read from two text files, one will be read and the other searched for the selected team.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary;
using System.IO;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Declare user variable
        string usrTeam;

        //Declare list variables
        List<string> teamsList = new List<string>();
        List<string> winnersList = new List<string>();
        
        //Open Text file and assign inputfile name
        StreamReader teamsInputFile = File.OpenText(@"../../../ClassLibrary/Docs/Teams.txt");
        StreamReader winnersInputFile = File.OpenText(@"../../../ClassLibrary/Docs/WorldSeriesWinners.txt");
        
        //Method for reading and adding teams to teamsListBox
        private void TeamsFile()
        {
            //Declare int counter
            int count = 0;

            //While loop EndOfStream and add to teamsListBox
            while(!teamsInputFile.EndOfStream)
            {
                teamsList.Add(teamsInputFile.ReadLine());
                teamsListBox.Items.Add(teamsList[count]);
                count++;
            }
            //Close teamsInputFile
            teamsInputFile.Close();

        }

        //Method for reading text doc and adding winners to list
        private void WinnersFile()
        {
            //Declare int counter
            int count = 0;

            //While loop EndOfStream and add winners to list
            while (!winnersInputFile.EndOfStream)
            {
                winnersList.Add(winnersInputFile.ReadLine());
                count++;
            }
            //Close winnersInputFile
            winnersInputFile.Close();

        }
        //Method to calculate how many times selected team has won
        private int TimesWon(string usrTeam)
        {
            //Declare int counter
            int count = 0;

            //for each loop with user selection and winners list
            foreach (string team in winnersList)
            {
                if (team == usrTeam)
                {
                    count++;
                }
            }
            //Return the count variable
            return count;
        }

        //Method for Displaying times won
        private void DisplayTimeWon()
        {
            int timesWon = TimesWon(usrTeam);
            MessageBox.Show("The selected team the " + usrTeam + " have " + timesWon + " World Series Championships!!!");
        }
                
        //Get user selection
        private void teamsListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //usrTeam variable
            usrTeam = teamsListBox.SelectedItem.ToString();
            //Display times won Method
            DisplayTimeWon();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TeamsFile();
            WinnersFile();

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
