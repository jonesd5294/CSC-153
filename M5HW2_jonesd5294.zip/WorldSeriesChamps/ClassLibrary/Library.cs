﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace ClassLibrary
{
    public static class Library
    {
        /**
        //Method to calculate how many times selected team has won
        public static int TimesWon(string usrTeam)
        {
            //Declare int counter
            int count = 0;

            //for each loop with user selection and winners list
            foreach (string team in winnersList)
            {
                if (team == usrTeam)
                {
                    count++;
                }
            }
            //Return the count variable
            return count;
        }
        */

    }
}
