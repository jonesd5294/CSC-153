﻿/**
 * 3/8/2023
 * CSC 153
 * David Jones
 * This program will write a file with random numbers between 1-100 defined by the user
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Call StreamWriter/Reader
using System.IO;
    

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
                    

        private void createButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare variables
                int number;
                Random rand = new Random();
                int counter;
                int rando = 0;
                StreamWriter outputFile;

                //If else statement
                //Call ShowDialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                                      
                    //Call user variables
                    number = int.Parse(numberTextBox.Text);
                   
                    //Create selected file
                    outputFile = File.CreateText(saveFileDialog.FileName);

                    //For Loop
                    for (counter = 1; counter <= number; counter++)
                    {
                        //Next random number, and write number to file
                        rando = rand.Next(100) + 1;
                        outputFile.WriteLine(rando);
                    }

                    //Close file
                    outputFile.Close();
                    
                }
                else
                {
                    //You clicked cancel message
                    MessageBox.Show("You clicked cancel.");
                }
                   
            
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter a number.");
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
