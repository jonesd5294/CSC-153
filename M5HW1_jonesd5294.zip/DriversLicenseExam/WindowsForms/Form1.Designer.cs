﻿
namespace WindowsForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loadLabel = new System.Windows.Forms.Label();
            this.resultsButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.wrongListBox = new System.Windows.Forms.ListBox();
            this.fileTextBox = new System.Windows.Forms.TextBox();
            this.resultsTextBox = new System.Windows.Forms.TextBox();
            this.resultsLabel = new System.Windows.Forms.Label();
            this.rightLabel = new System.Windows.Forms.Label();
            this.rightTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // loadLabel
            // 
            this.loadLabel.AutoSize = true;
            this.loadLabel.Location = new System.Drawing.Point(38, 32);
            this.loadLabel.Name = "loadLabel";
            this.loadLabel.Size = new System.Drawing.Size(47, 13);
            this.loadLabel.TabIndex = 0;
            this.loadLabel.Text = "Text File";
            // 
            // resultsButton
            // 
            this.resultsButton.Location = new System.Drawing.Point(118, 367);
            this.resultsButton.Name = "resultsButton";
            this.resultsButton.Size = new System.Drawing.Size(75, 23);
            this.resultsButton.TabIndex = 1;
            this.resultsButton.Text = "Results";
            this.resultsButton.UseVisualStyleBackColor = true;
            this.resultsButton.Click += new System.EventHandler(this.resultsButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(367, 367);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // wrongListBox
            // 
            this.wrongListBox.FormattingEnabled = true;
            this.wrongListBox.Location = new System.Drawing.Point(472, 176);
            this.wrongListBox.Name = "wrongListBox";
            this.wrongListBox.Size = new System.Drawing.Size(274, 121);
            this.wrongListBox.TabIndex = 3;
            // 
            // fileTextBox
            // 
            this.fileTextBox.Location = new System.Drawing.Point(201, 32);
            this.fileTextBox.Name = "fileTextBox";
            this.fileTextBox.Size = new System.Drawing.Size(100, 20);
            this.fileTextBox.TabIndex = 4;
            // 
            // resultsTextBox
            // 
            this.resultsTextBox.Location = new System.Drawing.Point(201, 98);
            this.resultsTextBox.Name = "resultsTextBox";
            this.resultsTextBox.Size = new System.Drawing.Size(100, 20);
            this.resultsTextBox.TabIndex = 6;
            // 
            // resultsLabel
            // 
            this.resultsLabel.AutoSize = true;
            this.resultsLabel.Location = new System.Drawing.Point(41, 104);
            this.resultsLabel.Name = "resultsLabel";
            this.resultsLabel.Size = new System.Drawing.Size(42, 13);
            this.resultsLabel.TabIndex = 7;
            this.resultsLabel.Text = "Results";
            // 
            // rightLabel
            // 
            this.rightLabel.AutoSize = true;
            this.rightLabel.Location = new System.Drawing.Point(41, 176);
            this.rightLabel.Name = "rightLabel";
            this.rightLabel.Size = new System.Drawing.Size(140, 13);
            this.rightLabel.TabIndex = 8;
            this.rightLabel.Text = "Number of correct questions";
            // 
            // rightTextBox
            // 
            this.rightTextBox.Location = new System.Drawing.Point(201, 168);
            this.rightTextBox.Name = "rightTextBox";
            this.rightTextBox.Size = new System.Drawing.Size(100, 20);
            this.rightTextBox.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rightTextBox);
            this.Controls.Add(this.rightLabel);
            this.Controls.Add(this.resultsLabel);
            this.Controls.Add(this.resultsTextBox);
            this.Controls.Add(this.fileTextBox);
            this.Controls.Add(this.wrongListBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resultsButton);
            this.Controls.Add(this.loadLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label loadLabel;
        private System.Windows.Forms.Button resultsButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox wrongListBox;
        private System.Windows.Forms.TextBox fileTextBox;
        private System.Windows.Forms.TextBox resultsTextBox;
        private System.Windows.Forms.Label resultsLabel;
        private System.Windows.Forms.Label rightLabel;
        private System.Windows.Forms.TextBox rightTextBox;
    }
}

