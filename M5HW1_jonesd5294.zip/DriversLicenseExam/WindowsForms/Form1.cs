﻿/**
 * 4/9/2023
 * CSC 153
 * David Jones
 * This program will grade a drivers license exam and display the results
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using ClassLibrary;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void resultsButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare variables
                int index = 0;
                
                //Declare exam answers in an array
                string[] ansArray = { "B", "D", "A", "A", "C", "A", "B", "A", "C", "D", "B", "C", "D", "A", "D", "C", "C", "B", "D", "A" };
                //Declare student answer array
                string[] studArray = new string[20];

                //Open file
                string textfile = fileTextBox.Text;
                StreamReader inputFile = File.OpenText(textfile);

                //Create while loop to read user text file and store in studArray
                while (!inputFile.EndOfStream)
                {
                    //store file in array
                    studArray[index] = inputFile.ReadLine();

                    //Call and display the correct answers
                    rightTextBox.Text = Library.CalLicExam(studArray, ansArray, index).ToString();

                }
                //Close file
                inputFile.Close();



            }

            catch (Exception)
            {
                MessageBox.Show("File not found.  Please try again.");
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
