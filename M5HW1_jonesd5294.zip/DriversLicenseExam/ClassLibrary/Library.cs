﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class Library
    { 
        //Create method for calculating the score on the drivers license exam
        public static int CalLicExam(string[] studArray, string[] ansArray, int index)
        {
            //Declare variables for correct number of answers
            int count = 0;

            //If else statement to compare arrays
            if (studArray[index] == ansArray[index])
                //Add to correct count
                count++;           
                
            //Return variables
                return count;
        }
    }
}
