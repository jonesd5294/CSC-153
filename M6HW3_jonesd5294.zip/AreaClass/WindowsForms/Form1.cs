﻿/**
 * 5/3/2023
 * CSC 153
 * David Jones
 * This program will calculate the area of a circle, rectangle, and cylinder using an area class
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Declare variables
        double radius;
        double width;
        double height;
        double length;
        double pi;


        private void circleButton_Click(object sender, EventArgs e)
        {
            //Get user variable radius
            radius = double.Parse(circRadTextBox.Text);

            //Call Area method for Cirlce
            MessageBox.Show("The area of the circle is " + Area.AreaCalc(radius).ToString("n2") + ".");


        }

        private void rectButton_Click(object sender, EventArgs e)
        {
            //Get user variable width
            width = double.Parse(recWidTextBox.Text);
            //Get user variable length
            length = double.Parse(recLenTextBox.Text);

            //Call Area method for Rectangle
            MessageBox.Show("The area of the rectangle is " + Area.AreaCalc(width, length).ToString("n2") + ".");

        }

        private void cyliButton_Click(object sender, EventArgs e)
        {
            //Assign PI to variable pi
            pi = Math.PI;
            //Get user variable radius
            radius = double.Parse(cyliRadTextBox.Text);
            //Get user variable heigth
            height = double.Parse(cyliHeiTextBox.Text);

            //Call Area Method for a Cylinder
            MessageBox.Show("The area of the cylinder is " + Area.AreaCalc(radius, height, pi).ToString("n2") + ".");

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
