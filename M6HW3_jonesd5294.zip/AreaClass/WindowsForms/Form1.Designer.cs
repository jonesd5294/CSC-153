﻿
namespace WindowsForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.circLabel = new System.Windows.Forms.Label();
            this.rectLabel = new System.Windows.Forms.Label();
            this.cyliLabel = new System.Windows.Forms.Label();
            this.circRadLabel = new System.Windows.Forms.Label();
            this.rectWidthLabel = new System.Windows.Forms.Label();
            this.rectLenLabel = new System.Windows.Forms.Label();
            this.circleButton = new System.Windows.Forms.Button();
            this.cyliRadLabel = new System.Windows.Forms.Label();
            this.cyliHeiLabel = new System.Windows.Forms.Label();
            this.circRadTextBox = new System.Windows.Forms.TextBox();
            this.recWidTextBox = new System.Windows.Forms.TextBox();
            this.recLenTextBox = new System.Windows.Forms.TextBox();
            this.cyliRadTextBox = new System.Windows.Forms.TextBox();
            this.cyliHeiTextBox = new System.Windows.Forms.TextBox();
            this.rectButton = new System.Windows.Forms.Button();
            this.cyliButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // circLabel
            // 
            this.circLabel.AutoSize = true;
            this.circLabel.Location = new System.Drawing.Point(119, 28);
            this.circLabel.Name = "circLabel";
            this.circLabel.Size = new System.Drawing.Size(33, 13);
            this.circLabel.TabIndex = 0;
            this.circLabel.Text = "Circle";
            // 
            // rectLabel
            // 
            this.rectLabel.AutoSize = true;
            this.rectLabel.Location = new System.Drawing.Point(391, 28);
            this.rectLabel.Name = "rectLabel";
            this.rectLabel.Size = new System.Drawing.Size(56, 13);
            this.rectLabel.TabIndex = 1;
            this.rectLabel.Text = "Rectangle";
            // 
            // cyliLabel
            // 
            this.cyliLabel.AutoSize = true;
            this.cyliLabel.Location = new System.Drawing.Point(640, 28);
            this.cyliLabel.Name = "cyliLabel";
            this.cyliLabel.Size = new System.Drawing.Size(44, 13);
            this.cyliLabel.TabIndex = 2;
            this.cyliLabel.Text = "Cylinder";
            // 
            // circRadLabel
            // 
            this.circRadLabel.AutoSize = true;
            this.circRadLabel.Location = new System.Drawing.Point(13, 61);
            this.circRadLabel.Name = "circRadLabel";
            this.circRadLabel.Size = new System.Drawing.Size(43, 13);
            this.circRadLabel.TabIndex = 3;
            this.circRadLabel.Text = "Radius:";
            // 
            // rectWidthLabel
            // 
            this.rectWidthLabel.AutoSize = true;
            this.rectWidthLabel.Location = new System.Drawing.Point(277, 61);
            this.rectWidthLabel.Name = "rectWidthLabel";
            this.rectWidthLabel.Size = new System.Drawing.Size(38, 13);
            this.rectWidthLabel.TabIndex = 5;
            this.rectWidthLabel.Text = "Width:";
            // 
            // rectLenLabel
            // 
            this.rectLenLabel.AutoSize = true;
            this.rectLenLabel.Location = new System.Drawing.Point(280, 121);
            this.rectLenLabel.Name = "rectLenLabel";
            this.rectLenLabel.Size = new System.Drawing.Size(43, 13);
            this.rectLenLabel.TabIndex = 6;
            this.rectLenLabel.Text = "Length:";
            // 
            // circleButton
            // 
            this.circleButton.Location = new System.Drawing.Point(97, 260);
            this.circleButton.Name = "circleButton";
            this.circleButton.Size = new System.Drawing.Size(75, 23);
            this.circleButton.TabIndex = 7;
            this.circleButton.Text = "Circle Area";
            this.circleButton.UseVisualStyleBackColor = true;
            this.circleButton.Click += new System.EventHandler(this.circleButton_Click);
            // 
            // cyliRadLabel
            // 
            this.cyliRadLabel.AutoSize = true;
            this.cyliRadLabel.Location = new System.Drawing.Point(548, 61);
            this.cyliRadLabel.Name = "cyliRadLabel";
            this.cyliRadLabel.Size = new System.Drawing.Size(43, 13);
            this.cyliRadLabel.TabIndex = 8;
            this.cyliRadLabel.Text = "Radius:";
            // 
            // cyliHeiLabel
            // 
            this.cyliHeiLabel.AutoSize = true;
            this.cyliHeiLabel.Location = new System.Drawing.Point(551, 120);
            this.cyliHeiLabel.Name = "cyliHeiLabel";
            this.cyliHeiLabel.Size = new System.Drawing.Size(41, 13);
            this.cyliHeiLabel.TabIndex = 9;
            this.cyliHeiLabel.Text = "Height:";
            // 
            // circRadTextBox
            // 
            this.circRadTextBox.Location = new System.Drawing.Point(97, 53);
            this.circRadTextBox.Name = "circRadTextBox";
            this.circRadTextBox.Size = new System.Drawing.Size(100, 20);
            this.circRadTextBox.TabIndex = 10;
            // 
            // recWidTextBox
            // 
            this.recWidTextBox.Location = new System.Drawing.Point(368, 52);
            this.recWidTextBox.Name = "recWidTextBox";
            this.recWidTextBox.Size = new System.Drawing.Size(100, 20);
            this.recWidTextBox.TabIndex = 11;
            // 
            // recLenTextBox
            // 
            this.recLenTextBox.Location = new System.Drawing.Point(368, 113);
            this.recLenTextBox.Name = "recLenTextBox";
            this.recLenTextBox.Size = new System.Drawing.Size(100, 20);
            this.recLenTextBox.TabIndex = 12;
            // 
            // cyliRadTextBox
            // 
            this.cyliRadTextBox.Location = new System.Drawing.Point(620, 53);
            this.cyliRadTextBox.Name = "cyliRadTextBox";
            this.cyliRadTextBox.Size = new System.Drawing.Size(100, 20);
            this.cyliRadTextBox.TabIndex = 13;
            // 
            // cyliHeiTextBox
            // 
            this.cyliHeiTextBox.Location = new System.Drawing.Point(620, 112);
            this.cyliHeiTextBox.Name = "cyliHeiTextBox";
            this.cyliHeiTextBox.Size = new System.Drawing.Size(100, 20);
            this.cyliHeiTextBox.TabIndex = 14;
            // 
            // rectButton
            // 
            this.rectButton.Location = new System.Drawing.Point(356, 260);
            this.rectButton.Name = "rectButton";
            this.rectButton.Size = new System.Drawing.Size(123, 23);
            this.rectButton.TabIndex = 15;
            this.rectButton.Text = "Rectangle Area";
            this.rectButton.UseVisualStyleBackColor = true;
            this.rectButton.Click += new System.EventHandler(this.rectButton_Click);
            // 
            // cyliButton
            // 
            this.cyliButton.Location = new System.Drawing.Point(620, 260);
            this.cyliButton.Name = "cyliButton";
            this.cyliButton.Size = new System.Drawing.Size(100, 23);
            this.cyliButton.TabIndex = 16;
            this.cyliButton.Text = "Cylinder Area";
            this.cyliButton.UseVisualStyleBackColor = true;
            this.cyliButton.Click += new System.EventHandler(this.cyliButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(368, 394);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 17;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.cyliButton);
            this.Controls.Add(this.rectButton);
            this.Controls.Add(this.cyliHeiTextBox);
            this.Controls.Add(this.cyliRadTextBox);
            this.Controls.Add(this.recLenTextBox);
            this.Controls.Add(this.recWidTextBox);
            this.Controls.Add(this.circRadTextBox);
            this.Controls.Add(this.cyliHeiLabel);
            this.Controls.Add(this.cyliRadLabel);
            this.Controls.Add(this.circleButton);
            this.Controls.Add(this.rectLenLabel);
            this.Controls.Add(this.rectWidthLabel);
            this.Controls.Add(this.circRadLabel);
            this.Controls.Add(this.cyliLabel);
            this.Controls.Add(this.rectLabel);
            this.Controls.Add(this.circLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label circLabel;
        private System.Windows.Forms.Label rectLabel;
        private System.Windows.Forms.Label cyliLabel;
        private System.Windows.Forms.Label circRadLabel;
        private System.Windows.Forms.Label rectWidthLabel;
        private System.Windows.Forms.Label rectLenLabel;
        private System.Windows.Forms.Button circleButton;
        private System.Windows.Forms.Label cyliRadLabel;
        private System.Windows.Forms.Label cyliHeiLabel;
        private System.Windows.Forms.TextBox circRadTextBox;
        private System.Windows.Forms.TextBox recWidTextBox;
        private System.Windows.Forms.TextBox recLenTextBox;
        private System.Windows.Forms.TextBox cyliRadTextBox;
        private System.Windows.Forms.TextBox cyliHeiTextBox;
        private System.Windows.Forms.Button rectButton;
        private System.Windows.Forms.Button cyliButton;
        private System.Windows.Forms.Button exitButton;
    }
}

