﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms
{
    class Area
    {      
        //Create Area Method for a Circle 
        public static double AreaCalc(double radius)
        {
            return (Math.PI) * (Math.Pow(radius,2));
        }

        //Create Area Method for a Rectangle
        public static double AreaCalc(double width, double length)
        {
            return width * length;
        }

        //Create Area Method for a Cylinder
        public static double AreaCalc(double radius, double height, double pi)
        {
            return pi * (Math.Pow(radius, 2) * height);
        }
    }
}
