﻿/**
 * 3/1/2023
 * CSC 153
 * David Jones
 * This program calculates pennies for pay
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        //Declare Variables
        int numDays;        
        decimal total;
        decimal pennies = 0.01m;
        decimal totalPay;


        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Get user input for number of days
            numDays = int.Parse(daysTextBox.Text);

            detailsListBox.Items.Add("Day  Pay");

            //For Loop and calculations
            for (int day = 1; day <= numDays; day++)
            {
                total = day * pennies;
                totalPay = total * 2;
                //Output to List box
                detailsListBox.Items.Add(day + "      " + totalPay.ToString("c"));

            }

        }
        //Exit Program
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
